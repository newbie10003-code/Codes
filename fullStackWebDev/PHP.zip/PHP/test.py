str = """I
Nilesh
Bhanot"""

print(str.split())