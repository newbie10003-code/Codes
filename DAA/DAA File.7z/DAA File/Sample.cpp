#include<bits/stdc++.h>
using namespace std;

void maxJobs(vector<pair<int, int>> &jobs, int n)
{
    sort(jobs.begin(), jobs.end());
    int maxEnd = 0, count = 0;

    for (auto i : jobs)
    {
        if (i.second > maxEnd)
            maxEnd = i.second;
    }

    vector<int> fill(maxEnd, -1);

    for (int i = 0; i < n; i++)
    {
        int j = jobs[i].second - 1;
        cout << j << " ";
        bool flag = true;
        while (j >= 0 && fill[j] == -1)
        {
            flag = false;
            fill[j] = 0;
            j--;
        }
        if(!flag)
            count++;
    }
    cout << endl << count << endl;
}

int main()
{
    int n;
    cin >> n;
    vector<pair<int, int>> jobs;
    int time, deadline;

    for (int i = 0; i < n; i++)
    {
        cin >> time >> deadline;
        jobs.push_back(make_pair(time, deadline));
    }
    maxJobs(jobs, n);
}