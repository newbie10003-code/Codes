<?php
    echo $_GET["name"]; // If get is used in form in html
    echo $_POST["name"];    // If post is used in form in html
    echo $_REQUEST["name"];     // Can be used either way, works for both get and post
    // Cookies
    
?>